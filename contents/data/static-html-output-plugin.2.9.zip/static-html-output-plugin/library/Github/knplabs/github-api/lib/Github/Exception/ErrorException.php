<?php

namespace Github\Exception;

/**
 * ErrorException.
 *
 * @author Joseph Bielawski <stloyd@gmail.com>
 */
class ErrorException extends \ErrorException implements ExceptionInterface
{
}
