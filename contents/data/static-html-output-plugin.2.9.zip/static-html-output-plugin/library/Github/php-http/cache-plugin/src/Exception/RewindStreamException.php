<?php

namespace Http\Client\Common\Plugin\Exception;

use Http\Client\Exception;

/**
 * @author Théo FIDRY <theo.fidry@gmail.com>
 */
class RewindStreamException extends \RuntimeException implements Exception
{
}
